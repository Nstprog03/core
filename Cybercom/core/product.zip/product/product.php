<?php require_once('Adapter.php'); ?>
<?php

class Product{

	public function gridAction()
	{
		//echo "111";
		require_once('product_grid.php');
	}

	public function saveAction()
	{
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			$adapter=new Adapter();
			
			$name=$_POST['product']['name'];
			$price=$_POST['product']['price'];
			$quantity=$_POST['product']['quantity'];
			$status=$_POST['product']['status'];
			$date=date('y-m-d h:m:s');

			if($_POST["submit"]=="Save")
			{
				$product=$adapter->insert("INSERT INTO `product` ( `name`, `price`, `quantity`, `status`, `created_date`) VALUES ( '$name', '$price', '$quantity', '$status', '$date')");
				if($product)
				{
					header('Location: product.php?a=gridAction');
				}

			}
			if($_POST["submit"]=="update")
			{
				$id=$_GET['id'];
				$product=$adapter->update("UPDATE `product` SET `name` = '$name', `price` = '$price', `quantity` = '$quantity', `status` = '$status', `updated_date` = '$date' WHERE `product`.`product_id` = $id");
				if($product)
				{
					header('Location: product.php?a=gridAction');
				}

			}
			
		}
	}

	public function editAction()
	{
		require_once('product_edit.php');
	}

	public function addAction()
	{
		require_once('product_add.php');
	}

	public function deleteAction()
	{
		
		if($_SERVER['REQUEST_METHOD']=='GET')
		{

				$id=$_GET['id'];
				$adapter =new Adapter();
				$product=$adapter->delete("DELETE FROM `product` WHERE `product`.`product_id` = '$id'");
				if($product)
				{
					echo "111";
					header('Location: product.php?a=gridAction');
				}
		}
	}

	public function errorAction()
	{
		echo "error";
	}


}

$action = ($_GET['a']) ? $_GET['a'] : 'errorAction';
$product = new Product();
$product->$action();

?>