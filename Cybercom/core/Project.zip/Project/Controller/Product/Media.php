<?php Ccc::loadClass('Controller_Core_Action') ?>
<?php

class Controller_Product_Media extends Controller_Core_Action{

	public function gridAction()
	{
		Ccc::getBlock('Media_Grid')->toHtml();
	}
	public function galleryAction()
	{
		Ccc::getBlock('Media_Gallery')->toHtml();
	}



	public function saveAction()
	{
		$request = $this->getRequest();
		$product_id = $request->getRequest('id');
		if($request->isPost()){
			try {
				$mediaModel = Ccc::getModel('Product_Media');
				$media = $mediaModel;
				$media->productId = $product_id;
				$file = $request->getFile();
				$ext = explode('.',$file['name']['name']);
				$fileExt = end($ext);
				$media->name = prev($ext)."".date('Ymdhis').".".$fileExt;
				$media->name = str_replace(" ","_",$media->name);
				$extension = array('jpg','jpeg','png');
				if(in_array($fileExt, $extension)){
					
					$result = $media->save();
					if(!$result){
						throw new Exception("System is unable to save your data.", 1);
					}	
					move_uploaded_file($file['name']['tmp_name'],$this->getView()->getBaseUrl("Media/Product/").$media->name);
				}
				$this->redirect($this->getView()->getUrl('grid','product_media'));	
			} catch (Exception $e) {
				echo $e->getMessage();
			}
			
		}
		
	}

	public function editAction()
	{
		try{
			$request = $this->getRequest();
			$productId = $request->getRequest('id');

			$mediaModel = Ccc::getModel('Product_Media');
			if(!$request->isPost()){
				throw new Exception("Invalid request.", 1);
			}
			$rows = $request->getPost();
			$media = $mediaModel;
			if(array_key_exists('media',$rows) && array_key_exists('base',$rows['media']))
			{
				$media->base = 2;
				$media->productId = $productId;
				$result = $media->save('productId');
				if($result)
				{
					$media->base = 1;
					$media->mediaId = $rows['media']['base'];
					$base = $media->save();
					unset($media->mediaId);
					unset($media->base);

				}
			}
			if(array_key_exists('media',$rows) && array_key_exists('thumb',$rows['media']))
			{
				
				$media->thumb = 2;
				$media->productId = $productId;
				$result = $media->save('productId');
				if($result)
				{
					$media->thumb = 1;
					$media->mediaId = $rows['media']['thumb'];
					$thumb = $media->save();
					unset($media->mediaId);
					unset($media->thumb);
				}
			}
			if(array_key_exists('media',$rows) && array_key_exists('small',$rows['media']))
			{
				
				$media->small = 2;
				$media->productId = $productId;
				$result = $media->save('productId');
				if($result)
				{
					$media->small = 1;
					$media->mediaId = $rows['media']['small'];
					$small = $media->save();
					unset($media->mediaId);
					unset($media->small);

				}
			}
			unset($media->productId);
			unset($rows['media']);
			foreach($rows as $row)
			{
				if(array_key_exists('remove',$row))
				{
					$result = $media->load($row['mediaId'])->delete();
					if(!$result)
					{
						throw new Exception("Invalid request", 1);
					}
					unlink($this->getView()->getBaseUrl("Media/Product/"). $row['name']);
				}

				if(array_key_exists('gallery',$row))
				{
					$media->mediaId = $row['mediaId'];
					$media->gallery = 1;
					$result = $media->save();
				}
				else
				{
					$media->mediaId = $row['mediaId'];
					$media->gallery = 2;
					$result = $media->save();
				}
			}
			$this->redirect($this->getView()->getUrl('grid','product_media',['id' => $productId],true));	
		}
		catch(Exception $e){
			echo $e->getMessage();
		}
	}
}

?>