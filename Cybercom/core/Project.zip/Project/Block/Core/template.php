<?php 

class Block_Core_Template extends Model_Core_View {

	
	
}


?>
