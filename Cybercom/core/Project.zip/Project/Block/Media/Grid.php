<?php Ccc::loadClass("Block_Core_Template"); ?>
<?php

class Block_Media_Grid extends Block_Core_Template
{
    public function __construct()
    {
        $this->setTemplate("view/product/media/grid.php");
    }

    public function getMedias()
    {
        $request = Ccc::getFront()->getRequest();
        $productId = $request->getRequest('id');
        $mediaModel = Ccc::getModel('Product_Media');
        $medias = $mediaModel->fetchAll("SELECT * FROM `media` WHERE `productId` = $productId ");
        return $medias;
    }
}

?>