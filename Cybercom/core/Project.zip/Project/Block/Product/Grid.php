<?php Ccc::loadClass('Block_Core_Template'); 

class Block_Product_Grid extends Block_Core_Template {

	public function __construct()
	{
		$this->setTemplate('view/product/grid.php');
	}
	public function getProducts()
	{
		$productModel = Ccc::getModel('Product');
		$query = "SELECT p.*,b.name as base,t.name as thumb,s.name as small FROM `product` as p 
        left join media as b ON p.`productId` = b.`productId` AND b.base = 1
        left join media as t ON p.`productId` = t.`productId` AND t.thumb = 1
        left join media as s ON p.`productId` = s.`productId` AND s.small = 1";
		$products = $productModel->fetchAll($query);
		return $products;	

	}
	
}


?>