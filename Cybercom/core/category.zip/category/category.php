<?php require_once('Adapter.php'); ?>
<?php

class Category{

	public function gridAction()
	{
		//echo "111";
		require_once('category_grid.php');
	}

	public function saveAction()
	{
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			$adapter=new Adapter();
			
			$name=$_POST['category']['name'];
			$status=$_POST['category']['status'];
			$date=date('y-m-d h:m:s');

			if($_POST["submit"]=="Save")
			{
				$category=$adapter->insert("INSERT INTO `category` ( `name`, `status`, `created_date`) VALUES ( '$name','$status', '$date')");
				if($category)
				{
					header('Location: category.php?a=gridAction');
				}

			}
			if($_POST["submit"]=="update")
			{
				$id=$_GET['id'];
				$category=$adapter->update("UPDATE `category` SET `name` = '$name', `status` = '$status', `updated_date` = '$date' WHERE `category`.`category_id` = $id");
				if($category)
				{
					header('Location: category.php?a=gridAction');
				}

			}
			
		}
	}

	public function editAction()
	{
		require_once('category_edit.php');
	}

	public function addAction()
	{
		require_once('category_add.php');
	}

	public function deleteAction()
	{
		
		if($_SERVER['REQUEST_METHOD']=='GET')
		{

				$id=$_GET['id'];
				$adapter =new Adapter();
				$category=$adapter->delete("DELETE FROM `category` WHERE `category`.`category_id` = '$id'");
				if($category)
				{
					echo "111";
					header('Location: category.php?a=gridAction');
				}
		}
	}

	public function errorAction()
	{
		echo "error";
	}


}

$action = ($_GET['a']) ? $_GET['a'] : 'errorAction';
$category = new category();
$category->$action();

?>