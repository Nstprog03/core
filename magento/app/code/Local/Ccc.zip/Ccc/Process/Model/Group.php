<?php 
class Ccc_Process_Model_Group extends Mage_Core_Model_Abstract
{
	public function _construct()
	{
		$this->_init('process/group');
	}
}