<?php   
   class Ccc_Process_Model_Product extends Ccc_Process_Model_Process_Abstract
   {
      protected $products;
      protected function _construct()
      {
         $this->_init('process/product');
      }

      public function getIdentifier($row)
      {
         return $row['sku'];
      }
      public function prepareRow($row)
      {
         return [
            'name' => $row['name'],
            'price' => $row['price'],
            'costPrice' => $row['costPrice'],
            'quantity' => $row['quantity'],
            'sku' => $row['sku'],
         ];
      }
      // public function verify()
      // {
      //    echo "<pre>";
      //   print_r($this->getProducts());
      //   exit;

      //   return true;          
      // }
      public function fetchProducts()
      {
         $select = $this->getCollection()
                    ->getSelect()
                    ->reset(Zend_Db_Select::COLUMNS)
                    ->columns(['product_id','sku']);
         return $this->getResource()->getReadConnection()->fetchPairs($select);
      }
      public function getProducts()
      {
         if(!$this->products)
         {
            $this->products = $this->fetchProducts();
         }
         return $this->products;
      }

      public function validateRow($row)
      {
         return $row;
      }
      public function import($entryData)
      {
         $products = $this->getProducts();
        foreach ($entryData as $key => $entry) 
        {
            $product = Mage::getModel('process/product');
            $product->setData(json_decode($entry['data'], true));
            if(in_array($product->sku,$products))
            {
               $product->product_id = array_search($product->sku,$products);
            }
            if(!$product->save())
            {
                throw new Exception("Data was not processed", 1);
            }
        }
      }
   }