<?php
class Ccc_User_Model_Resource_Setup extends Mage_Eav_Model_Entity_Setup {

}